import networkx as nx
import matplotlib.pyplot as plt
import os

# Ensure the output directory exists
output_dir = "../output/"
os.makedirs(output_dir, exist_ok=True)

# Create an undirected graph
G = nx.Graph()
G.add_edges_from([(1, 2), (1, 3), (2, 4), (3, 5), (4, 5)])
# Display the adjacency matrix

adj_matrix = nx.adjacency_matrix(G).todense()
print("Adjacency Matrix:")
print(adj_matrix)

# Save adjacency matrix to file with error handling
try:
    with open(os.path.join(output_dir, "adjacency_matrix.txt"), "w") as f:
        f.write(str(adj_matrix))
    print("Adjacency matrix saved successfully.")
except Exception as e:
    print(f"Error while saving adjacency matrix: {e}")

# Plot the graph
plt.figure(figsize=(8, 6))
nx.draw(G, with_labels=True, node_color='lightblue', edge_color='gray', node_size=500, font_size=15)
plt.title("Graph Visualization")
plt.savefig(os.path.join(output_dir, 'graph_visualization.png'))  # Save the plot
plt.show()

