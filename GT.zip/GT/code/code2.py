import networkx as nx

# Create an undirected graph
G = nx.Graph()
G.add_edges_from([(1, 2), (1, 3), (1, 4), (1, 5), (2, 6), (3, 7)])


# Compute degree centrality
degree_centrality = nx.degree_centrality(G)
print("Degree Centrality:", degree_centrality)

# Find the node(s) with the highest degree centrality
max_centrality = max(degree_centrality.values())  # Get the highest centrality value
nodes_with_max_centrality = [node for node, centrality in degree_centrality.items() if centrality == max_centrality]

print(f"The node(s) with the highest degree centrality is/are: {nodes_with_max_centrality}")
# Visualize the graph 
import matplotlib.pyplot as plt
plt.figure(figsize=(8, 6))
nx.draw(G, with_labels=True, node_color='lightblue', edge_color='gray', node_size=500, font_size=15)
plt.title("Graph Visualization")
plt.show()
