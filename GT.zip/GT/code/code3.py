import networkx as nx

# Create a graph where nodes represent cities
G = nx.Graph()
edges = [('A', 'B', 2), ('A', 'C', 5), ('B', 'D', 3), ('C', 'D', 1), ('C', 'E', 4)]
G.add_weighted_edges_from(edges)

# Compute closeness centrality
closeness_centrality = nx.closeness_centrality(G, distance='weight')
print("Closeness Centrality:", closeness_centrality)

# Find the most reachable node
most_reachable_node = max(closeness_centrality, key=closeness_centrality.get)
print(f"The most reachable city is: {most_reachable_node}")

# Save results
with open("../output/closeness_centrality.txt", "w") as f:
    f.write(str(closeness_centrality))
    f.write(f"\nThe most reachable city is: {most_reachable_node}")
