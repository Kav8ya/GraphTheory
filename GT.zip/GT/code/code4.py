import networkx as nx

# Create a transportation network graph with weighted edges
G = nx.Graph()
edges = [('A', 'B', 7), ('B', 'C', 5), ('B', 'D', 3), ('D', 'E', 2), ('C', 'E', 8)]
G.add_weighted_edges_from(edges)

# Compute betweenness centrality
betweenness_centrality = nx.betweenness_centrality(G, weight='weight')
print("Betweenness Centrality:", betweenness_centrality)

# Identify critical nodes (bridges)
critical_nodes = [node for node, centrality in betweenness_centrality.items() if centrality > 0.2]
print(f"Critical Nodes: {critical_nodes}")

# Save results
with open("../output/4qn/betweenness_centrality.txt", "w") as f:
    f.write(str(betweenness_centrality))
    f.write(f"\nCritical Nodes: {critical_nodes}")
