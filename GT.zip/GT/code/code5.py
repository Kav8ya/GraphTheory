import networkx as nx

# Create a directed citation network
G = nx.DiGraph()
edges = [('A', 'B'), ('A', 'C'), ('B', 'C'), ('C', 'D'), ('D', 'A')]
G.add_edges_from(edges)

# Compute prestige (in-degree centrality)
prestige = nx.in_degree_centrality(G)
print("Node Prestige:", prestige)

# Identify the most cited node
most_cited_node = max(prestige, key=prestige.get)
print(f"The most cited node is: {most_cited_node}")

# Save results
with open("../output/5qn/prestige.txt", "w") as f:
    f.write(str(prestige))
    f.write(f"\nThe most cited node is: {most_cited_node}")
