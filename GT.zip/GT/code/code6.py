import networkx as nx

# Create a graph
G = nx.Graph()
edges = [('A', 'B'), ('A', 'C'), ('B', 'D'), ('C', 'D'), ('C', 'E')]
G.add_edges_from(edges)

# Compute centralities
degree_centrality = nx.degree_centrality(G)
closeness_centrality = nx.closeness_centrality(G)
betweenness_centrality = nx.betweenness_centrality(G)

# Combine centralities with weights
combined_centrality = {node: 0.4 * degree_centrality[node] +
                            0.3 * closeness_centrality[node] +
                            0.3 * betweenness_centrality[node]
                       for node in G.nodes()}

# Rank nodes
ranked_nodes = sorted(combined_centrality.items(), key=lambda x: x[1], reverse=True)
print("Ranked Nodes by Combined Centrality:", ranked_nodes)

# Save results
with open("../output/6qn/combined_centrality.txt", "w") as f:
    f.write(str(ranked_nodes))
